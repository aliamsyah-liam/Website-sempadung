WEBSITE PROFIL SEMPADUNG - VERSI LENGKAP

5 halaman:
- index.html
- tentang.html
- potensi.html
- pendidikan.html
- galeri.html

Pendukung:
- style.css
- script.js
- images/

Fitur:
- Navigasi antarhalaman dalam satu website
- Responsif HP/desktop
- Animasi scroll
- Galeri klik untuk memperbesar foto
- Halaman sekolah SDN 21 Sempadung
- Peta lokasi sekolah
- Tombol Petunjuk Arah
- Tombol Website Sekolah
- Foto dokumentasi pengguna

Upload seluruh isi folder ke SATU repository GitHub Pages.

Foto tambahan:
- images/masjid-sempadung.jpg — foto masjid yang diunggah pengguna.


PEMBARUAN MASJID AL-JIHAD:
- Alamat: Jl. Raya Segedong, Sempadung, Segedong, Kecamatan Tebas, Kabupaten Sambas, Kalimantan Barat 79461, Indonesia.
- Ditambahkan detail lokasi, patokan, fungsi, catatan data, tombol Google Maps dan petunjuk arah pada halaman Potensi.
- Sumber alamat: informasi lokasi publik Masjid Al-Jihad Sempadung (Trip.com), diverifikasi melalui pencarian web pada 1 September 2026.
